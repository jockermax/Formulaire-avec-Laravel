<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>prjet laravel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  </head>
  <body>
    <div class="container text-center"><h1>Modifier un projet</h1> </div>
    <hr>
    <?php if(session('status')): ?>
      <div class ="alert alert-success">
        <?php echo e(session('status')); ?>


      </div>

    <?php endif; ?>


      <ul>
        <?php $__currentLoopData = $errors ->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="alert alert-danger"><?php echo e($error); ?> </li>
       
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>

    <form action="/modifier/traitement" method="POST" class="form-label">
      <?php echo csrf_field(); ?> 

     
        <div class="mb-3">
          <label for="code" class="form-label">code</label>
          <input type="text" class="form-control" id="code"name="code" value="<?php echo e($projets -> code); ?>">
          
        </div>
        <div class="mb-3">
            <label for="nom" class="form-label">nom</label>
            <input type="text" class="form-control" id="nom"name="nom" value="<?php echo e($projets -> nom); ?>" >
          
          </div>
          <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <input type="text" class="form-control" id="description"name="description" value="<?php echo e($projets -> description); ?>">
            
          </div>
          <div class="mb-3">
            <label for="budget" class="form-label">Budget</label>
            <input type="numbe" class="form-control" id="budget"name="budget" value="<?php echo e($projets -> budget); ?>">
            
          </div>
          <div class="mb-3">
            <label for="datedebut" class="form-label">Date DateDebut</label>
            <input type="date" class="form-control" id="datedebut"name="datedebut" value="<?php echo e($projets -> datedebut); ?>">
            
          </div>

          <div class="mb-3">
            <label for="datefin" class="form-label">DateFin</label>
            <input type="date" class="form-control" id="datefin"name="datefin" value="<?php echo e($projets -> datefin); ?>">
            
          </div>

          <div class="mb-3">
            <label for="statut" class="form-label">statut</label>
            <input type="boolean" class="form-control" id="statut"name="statut" value="<?php echo e($projets -> statut); ?>">
            
          </div>
          <div>
        <button type="submit" class="btn btn-primary">Modifier</button>

          
          <a  href="/projet" class="btn btn-danger">retour</a>
          </div>
      </form>
   
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH C:\xampp\htdocs\formulaire\resources\views/projet/modifier.blade.php ENDPATH**/ ?>