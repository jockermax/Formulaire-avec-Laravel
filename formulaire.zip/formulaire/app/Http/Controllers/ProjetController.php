<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\activite;
use App\Models\Projet;

class ProjetController extends Controller
{
   
    public function liste_projet(){
        $projets= Projet :: all();
        return view('projet.liste',compact('projets'));
    }

    public function ajouter_projet(){
        return view('projet.ajouter');
    }

    public function modifier_projet($id){
        $projets =Projet::find($id);
        return view('projet.modifier' , compact(('projets')));
    }

    public function supprimer_projet(){
        return view('projet.supprimer');
    }

    public function ajouter_projet_traitement(Request $request){
       $request -> validate([
        'code' => 'required',
        'nom' => 'required',
        'description' => 'required',
        'budget' => 'required',
        'datedebut' => 'required',
        'datefin' => 'required',
        'statut' => 'required',

    ]);
    /*
      $projet = new Projet();
      $projet -> code = $request -> code;
      $projet -> nom = $request -> nom;
      $projet -> description = $request -> description;
      $projet -> budget = $request -> budget;
      $projet -> datedebut = $request ->datedebut;
      $projet -> datefin = $request -> datefin;
      $projet -> statut = $request -> statut;
      $projet -> save();
*/

    //dd($request->all());
    Projet :: create($request->all());
      return redirect('/ajouter') -> with('status','Le projet est ajoute avec succes.');

}
    public function modifier_projet_traitement(Request $request){
        $request -> validate([
            'code' => 'required',
            'nom' => 'required',
            'description' => 'required',
            'budget' => 'required',
            'datedebut' => 'required',
            'datefin' => 'required',
            'statut' => 'required',
    
        ]);
          $projet =  Projet ::find($request->id);
          $projet -> code = $request -> code;
          $projet -> nom = $request -> nom;
          $projet -> description = $request -> description;
          $projet -> budget = $request -> budget;
          $projet -> datedebut = $request ->datedebut;
          $projet -> datefin = $request -> datefin;
          $projet -> statut = $request -> statut;
          $projet -> update();
        
    
          return redirect('/modifier') ;
    }

        
    

   
    

    
}
