<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProjetController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/modifier-projet/{id}',[ProjetController::class,'modifier_projet']);
Route::get('/projet',[ProjetController::class,'liste_projet']);
Route::post('/modifier/traitement',[ProjetController::class,'modifier_projet_traitement']);
Route::get('/ajouter',[ProjetController::class,'ajouter_projet']);
Route::get('/modifier',[ProjetController::class,'modifier_projet']);
Route::get('/supprimer',[ProjetController::class,'supprimer_projet']);
Route::post('/ajouter/traitement',[ProjetController::class,'ajouter_projet_traitement']);

