<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>prjet laravel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  </head>
  <body>
    <div class="container text-center"><h1>Ajouter un projet</h1> </div>
    <hr>
    @if(session('status'))
      <div class ="alert alert-success">
        {{
          session('status')
        }}

      </div>

    @endif


      <ul>
        @foreach ($errors ->all() as $error)
          <li class="alert alert-danger">{{$error}} </li>
       
            
        @endforeach
      </ul>

    <form action="/ajouter/traitement" method="POST" class="form-label">
      @csrf
        <div class="mb-3">
          <label for="code" class="form-label">code</label>
          <input type="text" class="form-control" id="code"name="code">
          
        </div>
        <div class="mb-3">
            <label for="nom" class="form-label">nom</label>
            <input type="text" class="form-control" id="nom"name="nom">
          
          </div>
          <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <input type="text" class="form-control" id="description" name="description">
            
          </div>
          <div class="mb-3">
            <label for="budget" class="form-label">Budget</label>
            <input type="numbe" class="form-control" id="budget" name="budget">
            
          </div>
          <div class="mb-3">
            <label for="datedebut" class="form-label">Date DateDebut</label>
            <input type="date" class="form-control" id="datedebut"name="datedebut">
            
          </div>

          <div class="mb-3">
            <label for="datefin" class="form-label">DateFin</label>
            <input type="date" class="form-control" id="datefin"name="datefin">
            
          </div>

          <div class="mb-3">
            <label for="statut" class="form-label">statut</label>
            <input type="boolean" class="form-control" id="statut"name="statut">
            
          </div>
          <div>
        <button href="/projet" type="submit" class="btn btn-primary">Ajouter</button>

          
          <a  href="/projet" class="btn btn-danger">retour</a>
          </div>
      </form>
   
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>